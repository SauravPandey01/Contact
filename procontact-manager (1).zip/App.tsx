
export { default } from './frontend/App';
