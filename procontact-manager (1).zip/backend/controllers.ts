
import { User, Contact } from '../frontend/types.ts';
import { STORAGE_KEYS, getStorage, setStorage } from './models.ts';

const generateId = () => Math.random().toString(36).substring(2, 9);

export const authController = {
  register: async (userData: Partial<User>) => {
    const users = getStorage<User[]>(STORAGE_KEYS.USERS, []);
    if (users.find(u => u.email === userData.email)) throw new Error('User already exists');
    const newUser: User = { id: generateId(), name: userData.name || 'User', email: userData.email!, password: userData.password };
    users.push(newUser);
    setStorage(STORAGE_KEYS.USERS, users);
    return newUser;
  },
  login: async (email: string, password: string) => {
    const users = getStorage<User[]>(STORAGE_KEYS.USERS, []);
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) throw new Error('Invalid credentials');
    const { password: _, ...safeUser } = user;
    setStorage(STORAGE_KEYS.SESSION, safeUser);
    return safeUser;
  }
};

export const contactController = {
  getContacts: async (userId: string) => {
    const contacts = getStorage<Contact[]>(STORAGE_KEYS.CONTACTS, []);
    return contacts.filter(c => c.userId === userId);
  },
  createContact: async (userId: string, data: Partial<Contact>) => {
    const contacts = getStorage<Contact[]>(STORAGE_KEYS.CONTACTS, []);
    if (contacts.find(c => c.userId === userId && c.email === data.email)) throw new Error('Email exists');
    const now = new Date().toISOString();
    const newContact: Contact = {
      id: generateId(), userId, name: data.name!, email: data.email!, phone: data.phone!,
      createdAt: now, updatedAt: now
    };
    contacts.push(newContact);
    setStorage(STORAGE_KEYS.CONTACTS, contacts);
    return newContact;
  },
  updateContact: async (id: string, data: Partial<Contact>) => {
    const contacts = getStorage<Contact[]>(STORAGE_KEYS.CONTACTS, []);
    const idx = contacts.findIndex(c => c.id === id);
    if (idx === -1) throw new Error('Not found');
    contacts[idx] = { ...contacts[idx], ...data, updatedAt: new Date().toISOString() };
    setStorage(STORAGE_KEYS.CONTACTS, contacts);
    return contacts[idx];
  },
  deleteContact: async (id: string) => {
    const contacts = getStorage<Contact[]>(STORAGE_KEYS.CONTACTS, []);
    setStorage(STORAGE_KEYS.CONTACTS, contacts.filter(c => c.id !== id));
  }
};
