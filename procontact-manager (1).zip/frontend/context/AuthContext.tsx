
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthState } from '../types.ts';
import { api } from '../api/contactsApi.ts';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>({ user: null, isAuthenticated: false, isLoading: true });

  useEffect(() => {
    api.auth.getCurrentUser().then(user => {
      setState({ user, isAuthenticated: !!user, isLoading: false });
    });
  }, []);

  const login = async (e: string, p: string) => {
    const user = await api.auth.login(e, p);
    setState({ user, isAuthenticated: true, isLoading: false });
  };

  const register = async (n: string, e: string, p: string) => {
    const user = await api.auth.register({ name: n, email: e, password: p });
    setState({ user, isAuthenticated: true, isLoading: false });
  };

  const logout = () => {
    api.auth.logout();
    setState({ user: null, isAuthenticated: false, isLoading: false });
  };

  return <AuthContext.Provider value={{ ...state, login, register, logout }}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const c = useContext(AuthContext);
  if (!c) throw new Error('useAuth must be within AuthProvider');
  return c;
};
