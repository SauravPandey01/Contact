
import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../api/contactsApi.ts';
import { Contact } from '../types.ts';
import { validateEmail, validatePhone } from '../utils/utils.ts';
import { ContactRow, Modal } from '../components/Components.tsx';

export const LoginPage = () => {
  const { login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isLogin) await login(form.email, form.password);
      else await register(form.name, form.email, form.password);
    } catch (err: any) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-indigo-600 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-md">
        <h2 className="text-3xl font-black text-center text-slate-800 mb-8">{isLogin ? 'Login' : 'Join Us'}</h2>
        {error && <div className="p-3 bg-rose-50 text-rose-600 rounded-xl mb-4 text-sm">{error}</div>}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && <input type="text" placeholder="Full Name" required className="w-full p-4 bg-slate-50 border rounded-2xl" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />}
          <input type="email" placeholder="Email" required className="w-full p-4 bg-slate-50 border rounded-2xl" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
          <input type="password" placeholder="Password" required className="w-full p-4 bg-slate-50 border rounded-2xl" value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
          <button disabled={loading} className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all">
            {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account')}
          </button>
        </form>
        <button onClick={() => setIsLogin(!isLogin)} className="w-full mt-6 text-indigo-600 text-sm font-medium">{isLogin ? "Need an account? Sign up" : "Have an account? Log in"}</button>
      </div>
    </div>
  );
};

export const ContactsPage = () => {
  const { user, logout } = useAuth();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState({ open: false, edit: null as Contact | null });
  const [form, setForm] = useState({ name: '', email: '', phone: '' });
  const [error, setError] = useState('');

  const refresh = async () => { if(user) setContacts(await api.contacts.getAll(user.id)); };
  useEffect(() => { refresh(); }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!validateEmail(form.email)) return setError('Invalid email');
    if(!validatePhone(form.phone)) return setError('Invalid phone');
    try {
      if(modal.edit) await api.contacts.update(modal.edit.id, form);
      else await api.contacts.create(user!.id, form);
      setModal({ open: false, edit: null });
      refresh();
    } catch(err: any) { setError(err.message); }
  };

  const filtered = useMemo(() => contacts.filter(c => c.name.toLowerCase().includes(search.toLowerCase())), [contacts, search]);

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b px-8 py-4 flex justify-between items-center sticky top-0 z-40">
        <h1 className="text-xl font-black text-indigo-600">ProContact</h1>
        <div className="flex items-center space-x-4">
          <span className="text-sm font-bold text-slate-700">{user?.name}</span>
          <button onClick={logout} className="text-rose-500 text-sm font-medium">Logout</button>
        </div>
      </nav>
      <main className="max-w-5xl mx-auto p-8">
        <div className="flex justify-between items-center mb-8">
          <input type="text" placeholder="Search..." className="p-3 border rounded-2xl w-full max-w-xs" value={search} onChange={e => setSearch(e.target.value)} />
          <button onClick={() => { setForm({name:'', email:'', phone:''}); setError(''); setModal({open:true, edit:null}); }} className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold">+ New</button>
        </div>
        <div className="bg-white rounded-3xl shadow-sm border overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-50"><tr className="text-xs font-bold text-slate-400 uppercase"><th className="px-6 py-4">Contact</th><th className="px-6 py-4">Email</th><th className="px-6 py-4">Phone</th><th className="px-6 py-4 text-right">Actions</th></tr></thead>
            <tbody>{filtered.map(c => <ContactRow key={c.id} contact={c} onEdit={(c) => { setForm(c); setError(''); setModal({open:true, edit:c}); }} onDelete={async id => { if(confirm('Delete?')) { await api.contacts.remove(id); refresh(); } }} />)}</tbody>
          </table>
        </div>
      </main>
      <Modal isOpen={modal.open} onClose={() => setModal({open:false, edit:null})} title={modal.edit ? 'Edit Contact' : 'New Contact'}>
        <form onSubmit={handleSave} className="space-y-4">
          {error && <div className="p-2 bg-rose-50 text-rose-600 text-xs rounded-lg">{error}</div>}
          <input placeholder="Name" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={form.name} onChange={e => setForm({...form, name:e.target.value})} required />
          <input placeholder="Email" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={form.email} onChange={e => setForm({...form, email:e.target.value})} required />
          <input placeholder="Phone" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={form.phone} onChange={e => setForm({...form, phone:e.target.value})} required />
          <button className="w-full py-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg">
            {modal.edit ? 'Update' : 'Create'}
          </button>
        </form>
      </Modal>
    </div>
  );
};
