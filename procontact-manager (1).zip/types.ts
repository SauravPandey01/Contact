
export interface User {
  id: string;
  email: string;
  name: string;
  password?: string;
}

export interface Contact {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export type SortField = 'name' | 'email' | 'createdAt';
export type SortOrder = 'asc' | 'desc';
