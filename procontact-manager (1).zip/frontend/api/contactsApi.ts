
import { authController, contactController } from '../../backend/controllers.ts';
import { User, Contact } from '../types.ts';

export const api = {
  auth: {
    login: authController.login,
    register: authController.register,
    logout: async () => localStorage.removeItem('pcm_session'),
    getCurrentUser: async () => {
      const stored = localStorage.getItem('pcm_session');
      return stored ? JSON.parse(stored) : null;
    }
  },
  contacts: {
    getAll: contactController.getContacts,
    create: contactController.createContact,
    update: contactController.updateContact,
    remove: contactController.deleteContact
  }
};
