
import { User, Contact } from '../frontend/types.ts';

// In a real app, this would be a real DB connection (Mongoose/Sequelize)
export const STORAGE_KEYS = {
  USERS: 'pcm_users',
  CONTACTS: 'pcm_contacts',
  SESSION: 'pcm_session'
};

export const getStorage = <T,>(key: string, defaultValue: T): T => {
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) : defaultValue;
};

export const setStorage = <T,>(key: string, value: T): void => {
  localStorage.setItem(key, JSON.stringify(value));
};
