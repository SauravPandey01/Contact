
import React from 'react';
import { Contact } from '../types.ts';
import { formatDate } from '../utils/utils.ts';

export const IconMail = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
export const IconPhone = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>;

export const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode }> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h3 className="text-lg font-bold text-slate-800">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-2">✕</button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
};

export const ContactRow: React.FC<{ contact: Contact; onEdit: (c: Contact) => void; onDelete: (id: string) => void }> = ({ contact, onEdit, onDelete }) => (
  <tr className="hover:bg-slate-50 border-b border-slate-100 last:border-0 transition-colors">
    <td className="px-6 py-4">
      <div className="flex items-center">
        <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
          {contact.name.charAt(0).toUpperCase()}
        </div>
        <div className="ml-4">
          <div className="text-sm font-semibold text-slate-900">{contact.name}</div>
          <div className="text-[10px] text-slate-400">Added {formatDate(contact.createdAt)}</div>
        </div>
      </div>
    </td>
    <td className="px-6 py-4 text-sm text-slate-600">
      <div className="flex items-center"><IconMail /><span className="ml-2">{contact.email}</span></div>
    </td>
    <td className="px-6 py-4 text-sm text-slate-600">
      <div className="flex items-center"><IconPhone /><span className="ml-2">{contact.phone}</span></div>
    </td>
    <td className="px-6 py-4 text-right space-x-2">
      <button onClick={() => onEdit(contact)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">✎</button>
      <button onClick={() => onDelete(contact.id)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">✕</button>
    </td>
  </tr>
);
