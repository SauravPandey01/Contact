
// This logic has been moved to frontend/pages/Pages.tsx
export {};
