
import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { LoginPage, ContactsPage } from './pages/Pages.tsx';

const AppContent: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <div className="h-screen flex items-center justify-center font-bold text-indigo-600 animate-pulse">Loading...</div>;
  return isAuthenticated ? <ContactsPage /> : <LoginPage />;
};

const App: React.FC = () => (
  <AuthProvider>
    <AppContent />
  </AuthProvider>
);

export default App;
