# Contacts Manager (ProContact)

A professional CRUD application for managing personal and professional contacts.

## Architecture
- **Backend**: Simulated Node/Express backend in the `/backend` folder.
- **Frontend**: React application organized into a modular folder structure in `/frontend`.

## Features
- **Auth**: Simple registration and login (simulated JWT).
- **CRUD**: Full Create, Read, Update, and Delete operations for contacts.
- **Search & Sort**: Filter by name/email and sort by various fields.
- **Pagination**: Client-side pagination for large contact lists.
- **Validation**: Regex-based email and phone validation.

## Setup & Run
1. Since this is a browser-based environment, the app runs automatically.
2. In a standard local environment:
   - Run `npm install` in both `frontend/` and `backend/` directories.
   - Run `npm run dev` in `frontend/` and `npm start` in `backend/`.
